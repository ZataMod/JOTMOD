import struct
import json
import os

def B2Js(blocks_data):
    offset = 140
    blocks = []
    def rv(fmt, size):
        nonlocal offset
        value = struct.unpack_from(fmt, blocks_data, offset)[0]
        offset += size
        return value
    def rvb():
        return rv("<B", 1) == 1
    def S(): return rv("<I", 4)
    def S2(): return rv("<H", 2)
    def S8(): return rv("<Q", 8)
    def I(): return rv("<i", 4)
    def I2(): return rv("<h", 2)
    def I8(): return rv("<q", 8)
    def B1(): return rv("<B", 1)
    def B2(): return rvb()
    
    def Str():
        nonlocal offset
        length = S()
        raw_bytes = blocks_data[offset:offset + length]
        offset += length
        return raw_bytes.decode("utf-8", errors="replace").strip("\x00")


    while offset < len(blocks_data):
        block = {}
        try:
            blockinfo = S()
            block['ID'] = S2()
            block['Name'] = Str()
            block['bMapEquipCfgUseRuleID'] = B1()
            block['bType'] = B1()
            block['Icon'] = Str()
            block['BuyPrice'] = S()
            block['FumoSwitchPrice'] = S()
            block['SalePrice'] = S()
            block['bIsTopGear'] = B2()
            
            block['PreEquipID'] = []
            for _ in range(3):
                value = S2()
                block['PreEquipID'].append(value)
            
            block['RequireEquip'] = Str()
            block['PhyAttack'] = S()
            block['AttackSpeed'] = S()
            block['CriticalHit'] = S()
            block['HealthSteal'] = S()
            block['MagicAttack'] = S()
            block['CDReduce'] = S()
            block['MagicPoint'] = S()
            block['MagicRecover'] = S()
            block['PhyDefence'] = S()
            block['MagicDefence'] = S()
            block['HealthPoint'] = S()
            block['HealthRecover'] = S()
            block['MoveSpeed'] = S()
            block['PhyArmorHurt'] = S()
            block['MgcArmorHurt'] = S()
            block['PhyArmorHurtRate'] = S()
            block['MgcArmorHurtRate'] = S()
            block['HurtOutputRate'] = S()
            block['HurtHurtReduceRate'] = S()
            block['MgcVamp'] = S()
            block['CriTeft'] = S()
            block['CtrlReduce'] = S()
            block['ActiveSkillID'] = S()
            block['ActiveSkillGroupID'] = S()
            block['ActiveSkillBeanID'] = S()
            block['ActiveSkillDes'] = Str()
            
            block['PassiveSkill'] = []
            for _ in range(4):
                skill = {
                    "ID": S(),
                    "Desc": Str(),
                    "UniquePassiveGroup": S2(),
                    "Priority": S2(),
                    "PassiveRmvSkillFuncID": [S() for _ in range(3)]
                }
                block['PassiveSkill'].append(skill)

                
            block['EffectCombine'] = []
            for _ in range(4):
                skill = {
                    "ID": S(),
                    "Desc": Str(),
                    "UniquePassiveGroup": S2(),
                    "Priority": S2()
                }
                block['EffectCombine'].append(skill)

            
            block['Desc'] = Str()
            block['bInvalid'] = B1()
            block['EquipStoryDes'] = Str()
            block['EquipTagDes'] = Str()
            block['AutoChessEquipType'] = S()
            block['AddFetterID1'] = S()
            block['AddFetterID2'] = S()
            block['bAcAutoEquip'] = B2()
            block['AcAddPopuNum'] = S()
            block['bIsAid'] = B2()
            block['BuyTimeLimit'] = S()
            block['DepsBuff'] = S()
            block['UpGradeEquipID'] = S2()
            block['UpGradeNeedBuff'] = S()
            block['EquipTreeDeps'] = S()
            block['bIsJungleKnight'] = B2()
            block['SwitchGroupID'] = I()


            
            blocks.append(block)
        except ValueError as e:
            print(f"Error reading block at offset {offset}: {e}")
            break

    return json.dumps(blocks, ensure_ascii=False, indent=4)

    



import hashlib


def JstoB(json_data, binary_file):
    blocks = json.loads(json_data)
    binary_data = bytearray()
    header = bytearray()
    header.extend(b'MSES\x07\x00\x00\x00')
    Blast = 0
    total_blocks = len(blocks)
    header.extend(struct.pack("<I", Blast))
    header.extend(struct.pack("<I", total_blocks))
    header.extend(b'\x61' * 32)
    header.extend(b'\x00' * 16 + b'UTF-8' + b'\x00' * 23)
    header.extend(b'\x00' * (140 - len(header)))
    binary_data.extend(header)

    def U(fmt, value):
        nonlocal block_data
        block_data.extend(struct.pack(fmt, value))
    def S1(value):
        nonlocal block_data
        block_data.extend(pack_string(value))
    for block in blocks:
        block_data = bytearray()
        
        U("<H", block.get('ID', 0))
        S1(block.get('Name', ""))
        block_data.append(block.get('bMapEquipCfgUseRuleID', 0))
        block_data.append(block.get('bType', 0))
        S1(block.get('Icon', ""))
        U("<I", block.get('BuyPrice', 0))
        U("<I", block.get('FumoSwitchPrice', 0))
        U("<I", block.get('SalePrice', 0))
        block_data.append(1 if block.get('bIsTopGear', False) else 0)
        for equip_id in block['PreEquipID']:
            U("<H", equip_id)
        
        
        S1(block.get('RequireEquip', ""))
        U("<I", block.get('PhyAttack', 0))
        U("<I", block.get('AttackSpeed', 0))
        U("<I", block.get('CriticalHit', 0))
        U("<I", block.get('HealthSteal', 0))
        U("<I", block.get('MagicAttack', 0))
        U("<I", block.get('CDReduce', 0))
        U("<I", block.get('MagicPoint', 0))
        U("<I", block.get('MagicRecover', 0))
        U("<I", block.get('PhyDefence', 0))
        U("<I", block.get('MagicDefence', 0))
        U("<I", block.get('HealthPoint', 0))
        U("<I", block.get('HealthRecover', 0))
        U("<I", block.get('MoveSpeed', 0))
        U("<I", block.get('PhyArmorHurt', 0))
        U("<I", block.get('MgcArmorHurt', 0))
        U("<I", block.get('PhyArmorHurtRate', 0))
        U("<I", block.get('MgcArmorHurtRate', 0))
        U("<I", block.get('HurtOutputRate', 0))
        U("<I", block.get('HurtHurtReduceRate', 0))
        U("<I", block.get('MgcVamp', 0))
        U("<I", block.get('CriTeft', 0))
        U("<I", block.get('CtrlReduce', 0))
        U("<I", block.get('ActiveSkillID', 0))
        U("<I", block.get('ActiveSkillGroupID', 0))
        U("<I", block.get('ActiveSkillBeanID', 0))
        S1(block.get('ActiveSkillDes', ""))
        
        for skill in block['PassiveSkill']:
            U("<I", skill["ID"])
            S1(skill["Desc"])
            U("<H", skill["UniquePassiveGroup"])
            U("<H", skill["Priority"])
            for func_id in skill["PassiveRmvSkillFuncID"]:
                U("<I", func_id)

        for effect in block['EffectCombine']:
            U("<I", effect["ID"])
            S1(effect["Desc"])
            U("<H", effect["UniquePassiveGroup"])
            U("<H", effect["Priority"])
        
        S1(block.get('Desc', ""))
        block_data.append(block.get('bInvalid', 0))
        S1(block.get('EquipStoryDes', ""))
        S1(block.get('EquipTagDes', ""))
        U("<I", block.get('AutoChessEquipType', 0))
        U("<I", block.get('AddFetterID1', 0))
        U("<I", block.get('AddFetterID2', 0))
        block_data.append(1 if block.get('bAcAutoEquip', False) else 0)
        U("<I", block.get('AcAddPopuNum', 0))
        block_data.append(1 if block.get('bIsAid', False) else 0)
        U("<I", block.get('BuyTimeLimit', 0))
        U("<I", block.get('DepsBuff', 0))
        U("<H", block.get('UpGradeEquipID', 0))
        U("<I", block.get('UpGradeNeedBuff', 0))
        U("<I", block.get('EquipTreeDeps', 0))
        block_data.append(1 if block.get('bIsJungleKnight', False) else 0)
        U("<i", block.get('SwitchGroupID', 0))



        Blen = len(block_data)
        final_block = struct.pack("<I", Blen) + block_data
        binary_data.extend(final_block)
        Bflast = Blen
 

    Blast = Bflast + 4
    binary_data[8:12] = struct.pack("<I", Blast)
    md5_hash = hashlib.md5(binary_data[140:]).hexdigest().encode('utf-8')
    binary_data[96:96 + len(md5_hash)] = md5_hash
    binary_data[140 - 12:140] = b'\x00\x00\x00\x00\x8c\x00\x00\x00\x00\x00\x00\x00'

    with open(binary_file, "wb") as bf:
        bf.write(binary_data)


def pack_string(value):
    encoded = value.encode('utf-8') + b'\x00'
    length = len(encoded)
    return struct.pack("<I", length) + encoded




def vinh(directory,mode):
    if mode == "1":
        with open(os.path.join(directory, "EquipInBattle.bytes"), "rb") as f:
            json_data = B2Js(f.read())
        with open(os.path.join(directory, "EquipInBattle.json"), "w", encoding="utf-8") as json_file:
            json_file.write(json_data)
        print("output: EquipInBattle.json")

    elif mode == "2":
        json_file_path = os.path.join(directory, "EquipInBattle.json")
        with open(json_file_path, "r", encoding="utf-8") as json_file:
            json_data = json_file.read()
        JstoB(json_data, os.path.join(directory, "EquipInBattle.bytes"))
        print("output: EquipInBattle.bytes")


