import struct
import json
import os

import struct
def B2Js(blocks_data):
    offset = 140
    blocks = []
    def rv(fmt, size):
        nonlocal offset
        value = struct.unpack_from(fmt, blocks_data, offset)[0]
        offset += size
        return value
    def rvb():
        return rv("<B", 1) == 1
    def S(): return rv("<I", 4)
    def S2(): return rv("<H", 2)
    def S8(): return rv("<Q", 8)
    def I(): return rv("<i", 4)
    def I2(): return rv("<h", 2)
    def I8(): return rv("<q", 8)
    def B1(): return rv("<B", 1)
    def B2(): return rvb()
    
    def Str():
        nonlocal offset
        length = S()
        raw_bytes = blocks_data[offset:offset + length]
        offset += length
        return raw_bytes.decode("utf-8", errors="replace").strip("\x00")



    while offset < len(blocks_data):
        block = {}
        try:
            blockinfo = S()
            block['bGrade'] = B1()
            block['bSequence'] = B1()
            block['bIsUsed'] = B2()
            block['GradeDesc'] = Str()
            block['GradeUpNeedFightCnt'] = I()
            block['GradeUpNeedWinCnt'] = I()
            block['GradeUpNeedScore'] = S()
            block['GradePicturePath'] = Str()
            block['GradePicturePathSuperMaster'] = Str()
            block['GradeSmallPicPath'] = Str()
            block['GradeSmallPicPathSuperMaster'] = Str()
            block['GradeFramePicPath'] = Str()
            block['GradeFramePicPathSuperMaster'] = Str()
            block['TRankAdjustMMR'] = I()
            block['GuildSignInPoint'] = S()
            block['MultiMatchMMRAdjustValue'] = I()
            block['BaseMMR'] = I()
            block['ConWinCnt'] = S()
            block['bBelongBigGrade'] = B1()
            block['BigGradeName'] = Str()
            block['BigGradeDesc'] = Str()
            block['BigGradeTips'] = Str()
            block['bSmallGrade'] = B1()
            block['SmallGradeName'] = Str()
            block['RewardDesc'] = Str()
            block['FiveCampMMRAddValue'] = S()
            block['AddStarScore'] = S()
            block['ConWinScore'] = []
            for _ in range(5):
                value = S()
                block['ConWinScore'].append(value)
            block['ConLossScore'] = []
            for _ in range(5):
                value = S()
                block['ConLossScore'].append(value)
            block['MVPScore'] = []
            for _ in range(5):
                value = S()
                block['MVPScore'].append(value)
            block['BeAFKCompensate'] = []
            for _ in range(7):
                value = I()
                block['BeAFKCompensate'].append(value)
            block['NormalMatchMMR'] = I()
            block['ProtectGradeMinScore'] = S()
            block['bIsNeedAloneIPMatch'] = B2()
            block['BaseFightScoreOfGrade'] = S()
            block['FightScoreOfEachStar'] = S()
            block['NationalBattleInitMatchScore'] = S()
            block['NationalBattleScoreEachStar'] = S()
            block['NationalBattleFixScore'] = I()
            block['BeAFKDefeatAddActiveScore'] = []
            for _ in range(10):
                value = I()
                block['BeAFKDefeatAddActiveScore'].append(value)
            block['BeAFKVictoryAddActiveScore'] = []
            for _ in range(10):
                value = I()
                block['BeAFKVictoryAddActiveScore'].append(value)
            block['ELOInitScore'] = I()
            block['ELOMinScore'] = I()
            block['ELOMaxScore'] = I()
            block['ELOAIScore'] = I()
            block['ELOScorePerStart'] = I()
            block['HeroDifficultyIndex'] = I()
            block['RankStarBuffCnt'] = I()
            block['DailyFirstRankAddCoinPrecent'] = I()
            block['DailyFirstRankAddExpPrecent'] = I()
            block['DailyFirstRankAddScore'] = I()
            block['CrossServerRankAdjustMMR'] = I()
            block['CrossServerMatchAdjustMMR'] = I()
            block['SeasonReviewRankRatio'] = I()
            block['SeasonReviewBigGradeRatioDesc'] = Str()
            block['Rank2MatchMMRAdjustValue'] = I()
            block['Rank3MatchMMRAdjustValue'] = I()
            block['Rank5MatchMMRAdjustValue'] = I()

            
            blocks.append(block)
        except ValueError as e:
            print(f"Error reading block at offset {offset}: {e}")
            break

    return json.dumps(blocks, ensure_ascii=False, indent=4)

    



import hashlib


def JstoB(json_data, binary_file):
    blocks = json.loads(json_data)
    binary_data = bytearray()
    header = bytearray()
    header.extend(b'MSES\x07\x00\x00\x00')
    Blast = 0
    total_blocks = len(blocks)
    header.extend(struct.pack("<I", Blast))
    header.extend(struct.pack("<I", total_blocks))
    header.extend(b'\x61' * 32)
    header.extend(b'\x00' * 16 + b'UTF-8' + b'\x00' * 23)
    header.extend(b'\x00' * (140 - len(header)))
    binary_data.extend(header)

    def U(fmt, value):
        nonlocal block_data
        block_data.extend(struct.pack(fmt, value))
    def S1(value):
        nonlocal block_data
        block_data.extend(pack_string(value))
    for block in blocks:
        block_data = bytearray()
        
        block_data.append(block.get('bGrade', 0))
        block_data.append(block.get('bSequence', 0))
        block_data.append(1 if block.get('bIsUsed', False) else 0)
        S1(block.get('GradeDesc', ""))
        U("<i", block.get('GradeUpNeedFightCnt', 0))
        U("<i", block.get('GradeUpNeedWinCnt', 0))
        U("<I", block.get('GradeUpNeedScore', 0))
        S1(block.get('GradePicturePath', ""))
        S1(block.get('GradePicturePathSuperMaster', ""))
        S1(block.get('GradeSmallPicPath', ""))
        S1(block.get('GradeSmallPicPathSuperMaster', ""))
        S1(block.get('GradeFramePicPath', ""))
        S1(block.get('GradeFramePicPathSuperMaster', ""))
        U("<i", block.get('TRankAdjustMMR', 0))
        U("<I", block.get('GuildSignInPoint', 0))
        U("<i", block.get('MultiMatchMMRAdjustValue', 0))
        U("<i", block.get('BaseMMR', 0))
        U("<I", block.get('ConWinCnt', 0))
        block_data.append(block.get('bBelongBigGrade', 0))
        S1(block.get('BigGradeName', ""))
        S1(block.get('BigGradeDesc', ""))
        S1(block.get('BigGradeTips', ""))
        block_data.append(block.get('bSmallGrade', 0))
        S1(block.get('SmallGradeName', ""))
        S1(block.get('RewardDesc', ""))
        U("<I", block.get('FiveCampMMRAddValue', 0))
        U("<I", block.get('AddStarScore', 0))

        for sub_id in block.get('ConWinScore', []):
            U("<I", sub_id)
        for sub_id in block.get('ConLossScore', []):
            U("<I", sub_id)
        for sub_id in block.get('MVPScore', []):
            U("<I", sub_id)
        for sub_id in block.get('BeAFKCompensate', []):
            U("<i", sub_id)
            
        U("<i", block.get('NormalMatchMMR', 0))
        U("<I", block.get('ProtectGradeMinScore', 0))
        block_data.append(1 if block.get('bIsNeedAloneIPMatch', False) else 0)
        U("<I", block.get('BaseFightScoreOfGrade', 0))
        U("<I", block.get('FightScoreOfEachStar', 0))
        U("<I", block.get('NationalBattleInitMatchScore', 0))
        U("<I", block.get('NationalBattleScoreEachStar', 0))
        U("<i", block.get('NationalBattleFixScore', 0))
        for sub_id in block.get('BeAFKDefeatAddActiveScore', []):
            U("<i", sub_id)
        for sub_id in block.get('BeAFKVictoryAddActiveScore', []):
            U("<i", sub_id)
        U("<i", block.get('ELOInitScore', 0))
        U("<i", block.get('ELOMinScore', 0))
        U("<i", block.get('ELOMaxScore', 0))
        U("<i", block.get('ELOAIScore', 0))
        U("<i", block.get('ELOScorePerStart', 0))
        U("<i", block.get('HeroDifficultyIndex', 0))
        U("<i", block.get('RankStarBuffCnt', 0))
        U("<i", block.get('DailyFirstRankAddCoinPrecent', 0))
        U("<i", block.get('DailyFirstRankAddExpPrecent', 0))
        U("<i", block.get('DailyFirstRankAddScore', 0))
        U("<i", block.get('CrossServerRankAdjustMMR', 0))
        U("<i", block.get('CrossServerMatchAdjustMMR', 0))
        U("<i", block.get('SeasonReviewRankRatio', 0))
        S1(block.get('SeasonReviewBigGradeRatioDesc', ""))
        U("<i", block.get('Rank2MatchMMRAdjustValue', 0))
        U("<i", block.get('Rank3MatchMMRAdjustValue', 0))
        U("<i", block.get('Rank5MatchMMRAdjustValue', 0))


        Blen = len(block_data)
        final_block = struct.pack("<I", Blen) + block_data
        binary_data.extend(final_block)
        Bflast = Blen
 

    Blast = Bflast + 4
    binary_data[8:12] = struct.pack("<I", Blast)
    md5_hash = hashlib.md5(binary_data[140:]).hexdigest().encode('utf-8')
    binary_data[96:96 + len(md5_hash)] = md5_hash
    binary_data[140 - 12:140] = b'\x00\x00\x00\x00\x8c\x00\x00\x00\x00\x00\x00\x00'

    with open(binary_file, "wb") as bf:
        bf.write(binary_data)


def pack_string(value):
    encoded = value.encode('utf-8') + b'\x00'
    length = len(encoded)
    return struct.pack("<I", length) + encoded




def vinh(directory,mode):
    if mode == "1":
        with open(os.path.join(directory, "RankGrade.bytes"), "rb") as f:
            json_data = B2Js(f.read())
        with open(os.path.join(directory, "RankGrade.json"), "w", encoding="utf-8") as json_file:
            json_file.write(json_data)
        print("output: RankGrade.json")

    elif mode == "2":
        json_file_path = os.path.join(directory, "RankGrade.json")
        with open(json_file_path, "r", encoding="utf-8") as json_file:
            json_data = json_file.read()
        JstoB(json_data, os.path.join(directory, "RankGrade.bytes"))
        print("output: RankGrade.bytes")


