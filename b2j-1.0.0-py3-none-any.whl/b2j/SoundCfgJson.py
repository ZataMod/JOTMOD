import struct
import json
import os
print("Danh sách file hỗ trợ: Databin/Sound/...\n")


def B2Js(blocks_data):
    offset = 140
    blocks = []
    def rv(fmt, size):
        nonlocal offset
        value = struct.unpack_from(fmt, blocks_data, offset)[0]
        offset += size
        return value
    def rvb():
        return rv("<B", 1) == 1
    def S(): return rv("<I", 4)
    def S2(): return rv("<H", 2)
    def S8(): return rv("<Q", 8)
    def I(): return rv("<i", 4)
    def I2(): return rv("<h", 2)
    def I8(): return rv("<q", 8)
    def B1(): return rv("<B", 1)
    def B2(): return rvb()
    
    def Str():
        nonlocal offset
        length = S()
        raw_bytes = blocks_data[offset:offset + length]
        offset += length
        return raw_bytes.decode("utf-8", errors="replace").strip("\x00")


    while offset < len(blocks_data):
        block = {}
        try:
            blockinfo = S()
            block['CfgID'] = S()
            block['EventName'] = Str()
            block['HeroSkinID'] = S()
            block['MonsterID'] = S()
            block['OrganID'] = S()
            block['bType'] = B1()
            block['bFilter'] = B1()
            block['Param1'] = I()
            block['Param2'] = I()
            block['Param3'] = Str()
            block['Param4'] = Str()

            
            blocks.append(block)
        except ValueError as e:
            print(f"Error reading block at offset {offset}: {e}")
            break

    return json.dumps(blocks, ensure_ascii=False, indent=4)

    



import hashlib


def JstoB(json_data, binary_file):
    blocks = json.loads(json_data)
    binary_data = bytearray()
    header = bytearray()
    header.extend(b'MSES\x07\x00\x00\x00')
    Blast = 0
    total_blocks = len(blocks)
    header.extend(struct.pack("<I", Blast))
    header.extend(struct.pack("<I", total_blocks))
    header.extend(b'\x61' * 32)
    header.extend(b'\x00' * 16 + b'UTF-8' + b'\x00' * 23)
    header.extend(b'\x00' * (140 - len(header)))
    binary_data.extend(header)

    def U(fmt, value):
        nonlocal block_data
        block_data.extend(struct.pack(fmt, value))
    def S1(value):
        nonlocal block_data
        block_data.extend(pack_string(value))
    for block in blocks:
        block_data = bytearray()
        
        
        U("<I", block.get('CfgID', 0))
        S1(block.get('EventName', ""))
        U("<I", block.get('HeroSkinID', 0))
        U("<I", block.get('MonsterID', 0))
        U("<I", block.get('OrganID', 0))
        block_data.append(block.get('bType', 0))
        block_data.append(block.get('bFilter', 0))
        U("<i", block.get('Param1', 0))
        U("<i", block.get('Param2', 0))
        S1(block.get('Param3', ""))
        S1(block.get('Param4', ""))



        Blen = len(block_data)
        final_block = struct.pack("<I", Blen) + block_data
        binary_data.extend(final_block)
        Bflast = Blen
 

    Blast = Bflast + 4
    binary_data[8:12] = struct.pack("<I", Blast)
    md5_hash = hashlib.md5(binary_data[140:]).hexdigest().encode('utf-8')
    binary_data[96:96 + len(md5_hash)] = md5_hash
    binary_data[140 - 12:140] = b'\x00\x00\x00\x00\x8c\x00\x00\x00\x00\x00\x00\x00'

    with open(binary_file, "wb") as bf:
        bf.write(binary_data)


def pack_string(value):
    encoded = value.encode('utf-8') + b'\x00'
    length = len(encoded)
    return struct.pack("<I", length) + encoded


Vfile = [
    "ACHeroBank", "ACHeroSound", "BattleBank", "ChatSound", "CoupleSound",
    "HeroSound", "LobbyBank", "LobbySound", "MonsterAndOrganSound",
    "SceneSound"
]

def vinh(directory,mode):
    if mode == "1":
        for filename in os.listdir(directory):
            if any(filename.startswith(name) for name in Vfile) and filename.endswith(".bytes"):
                input_path = os.path.join(directory, filename)
                output_path = os.path.join(directory, filename.replace(".bytes", ".json"))
                
                with open(input_path, "rb") as f:
                    json_data = B2Js(f.read())
                with open(output_path, "w", encoding="utf-8") as json_file:
                    json_file.write(json_data)
                
                print(f"Output: {output_path}")

    elif mode == "2":
        for filename in os.listdir(directory):
            if any(filename.startswith(name) for name in Vfile) and filename.endswith(".json"):
                input_path = os.path.join(directory, filename)
                output_path = os.path.join(directory, filename.replace(".json", ".bytes"))
                
                with open(input_path, "r", encoding="utf-8") as json_file:
                    json_data = json_file.read()
                JstoB(json_data, output_path)
                
                print(f"Output: {output_path}")



