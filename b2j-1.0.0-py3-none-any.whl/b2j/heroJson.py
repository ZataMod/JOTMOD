import struct
import json
import os
from itertools import dropwhile

def zro(lst):
    return list(reversed(list(dropwhile(lambda x: x == 0, reversed(lst)))))

def B2Js(blocks_data):
    offset = 140
    blocks = []
    def rv(fmt, size):
        nonlocal offset
        value = struct.unpack_from(fmt, blocks_data, offset)[0]
        offset += size
        return value
    def rvb():
        return rv("<B", 1) == 1
    def S(): return rv("<I", 4)
    def S2(): return rv("<H", 2)
    def S8(): return rv("<Q", 8)
    def I(): return rv("<i", 4)
    def I2(): return rv("<h", 2)
    def I8(): return rv("<q", 8)
    def B1(): return rv("<B", 1)
    def B2(): return rvb()
    
    def Str():
        nonlocal offset
        length = S()
        raw_bytes = blocks_data[offset:offset + length]
        offset += length
        return raw_bytes.decode("utf-8", errors="replace").strip("\x00")

    while offset < len(blocks_data):
        block = {}
        try:
            blockinfo = S()
            block['CfgID'] = S()
            block['IDType'] = S()
            block['Name'] = Str()
            block['NamePinYin'] = Str()
            block['bIsTrainUse'] = B2()
            block['HeroTitle'] = Str()
            block['ImagePath'] = Str()
            block['CharacterInfo'] = Str()
            block['RecommendPosition'] = I()
            block['bAttackDistanceType'] = B1()
            block['SightR'] = I()
            block['BaseHP'] = I()
            block['BaseHPAdd'] = I()
            block['HPAddLvlup'] = I()
            block['BaseATT'] = I()
            block['BaseINT'] = I()
            block['BaseDEF'] = I()
            block['BaseRES'] = I()
            block['BaseSpeed'] = I()
            block['AtkSpdAddLvlup'] = I()
            block['BaseAtkSpd'] = I()
            block['CritRate'] = I()
            block['CritEft'] = I()
            block['HpGrowth'] = I()
            block['AtkGrowth'] = I()
            block['SpellGrowth'] = I()
            block['DefGrowth'] = I()
            block['ResistGrowth'] = I()
            block['PassiveID1'] = I()
            block['PassiveID2'] = I()
            block['BuffID1'] = I()
            block['BuffID2'] = I()
            block['BuffID3'] = I()
            block['SkillInfo'] = [{"SkillID": I(), "PassiveSkillID": I(), "UnlockStar": S2(), "SkillBeanID": S()} for _ in range(5)]
            block['InitialStar'] = I()
            block['bType'] = B1()
            block['bExpandType'] = B1()
            block['PVPNeedLevel'] = S2()
            block['PVPNeedQuality'] = I()
            block['PVPNeedSubQuality'] = I()
            block['PVPNeedStar'] = I()
            block['Viability'] = I()
            block['PhyDamage'] = I()
            block['SpellDamage'] = I()
            block['StartedDifficulty'] = I()
            block['bJob'] = B1()
            block['bSecondJob'] = B1()
            block['JobFeature'] = zro([I() for _ in range(2)])
            block['bDamageType'] = B1()
            block['bAttackType'] = B1()
            block['HeroDesc'] = Str()
            block['NewbieHeroDesc'] = Str()
            block['bIOSHide'] = B2()
            block['ShowSortId'] = S()
            block['AI_Entry'] = Str()
            block['AI_Simple'] = Str()
            block['AI_Normal'] = Str()
            block['AI_Hard'] = Str()
            block['AI_WarmSimple'] = Str()
            block['AI_Warm'] = Str()
            block['AI_WarmFiveCamp'] = Str()
            block['WakeDesc'] = Str()
            block['WakeTalentID'] = S()
            block['WakeSkinID'] = S()
            block['AttackRangeDesc'] = Str()
            block['EnergyType'] = S()
            block['Energy'] = I()
            block['EnergyGrowth'] = I()
            block['EnergyRec'] = I()
            block['EnergyRecGrowth'] = I()
            block['EnergyType2'] = S()
            block['Energy2'] = I()
            block['EnergyGrowth2'] = I()
            block['EnergyRec2'] = I()
            block['EnergyRecGrowth2'] = I()
            block['HeroTips'] = Str()
            block['HeroSound'] = Str()
            block['SymbolRcmdID'] = S()
            block['Born_Age'] = Str()
            block['Revive_Age'] = Str()
            block['DeadControl'] = S()
            block['bTag'] = B1()
            block['bHeroCamp'] = B1()
            block['bIsDCHero'] = B2()
            block['bIsHeroStoryLink'] = B2()
            block['BuffMarkSlotNum'] = I()
            block['BuffMarkOverlapRule'] = I()
            block['HeroWarmTips'] = Str()
            block['HeroTrainDrawPicName'] = Str()
            block['RecentAdapter'] = I()
            block['AdapterBeginTime'] = S8()
            block['AdapterEndTime'] = S8()
            block['AdapterURL'] = Str()
            block['HeroStoryURL'] = Str()
            block['MainLane'] = S()
            block['ViceLane'] = S()
            block['NotRecommendedLane'] = zro([S() for _ in range(4)])
            block['HeroReportDrawPicName'] = Str()
            block['HeroDrawPicNameUpdated'] = I()
            block['HeroBattleSkill'] = zro([S() for _ in range(10)])
            block['DefaultSelSkill'] = S()
            block['SkillLevelUpGuide'] = S()
            block['NormalGoldNeedScore'] = S()
            block['NormalSilverNeedScore'] = S()
            block['MasterGoldNeedScore'] = S()
            block['MasterSilverNeedScore'] = S()
            block['RankStarGoldNeedScore'] = S()
            block['RankStarSilverNeedScore'] = S()
            block['RankDiamondGoldNeedScore'] = S()
            block['RankDiamondSilverNeedScore'] = S()
            block['RankPlatinumGoldNeedScore'] = S()
            block['RankPlatinumSilverNeedScore'] = S()
            block['RankBronzeGoldNeedScore'] = S()
            block['RankBronzeSilverNeedScore'] = S()
            block['MinimalScore'] = S()
            block['GoldGuarantee'] = S()
            block['AILane'] = S()
            block['NormalHeroID'] = S()
            block['HeroFightDesc'] = Str()
            block['SecondSkillInfo'] = zro([I() for _ in range(4)])
            block['HeroStrategy'] = Str()
            block['HeroAdjustContent'] = Str()
            block['bIsInTestingHero'] = B2()
            block['HeroCounterTips'] = Str()
            block['HighlightMvpInfo'] = [{"MvpStdScore": S(), "MvpMinScore": S()} for _ in range(8)]
            block['ReturnExtarJson'] = Str()

                
            blocks.append(block)
        except ValueError as e:
            print(f"Error reading block at offset {offset}: {e}")
            break

    return json.dumps(blocks, ensure_ascii=False, indent=4)

    



import hashlib


def JstoB(json_data, binary_file):
    blocks = json.loads(json_data)
    binary_data = bytearray()
    header = bytearray()
    header.extend(b'MSES\x07\x00\x00\x00')
    Blast = 0
    total_blocks = len(blocks)
    header.extend(struct.pack("<I", Blast))
    header.extend(struct.pack("<I", total_blocks))
    header.extend(b'\x61' * 32)
    header.extend(b'\x00' * 16 + b'UTF-8' + b'\x00' * 23)
    header.extend(b'\x00' * (140 - len(header)))
    binary_data.extend(header)

    def U(fmt, value):
        nonlocal block_data
        block_data.extend(struct.pack(fmt, value))
    def S1(value):
        nonlocal block_data
        block_data.extend(pack_string(value))
    for block in blocks:
        block_data = bytearray()
                
        U("<I", block.get('CfgID', 0))
        U("<I", block.get('IDType', 0))
        S1(block.get('Name', ""))
        S1(block.get('NamePinYin', ""))
        block_data.append(1 if block.get('bIsTrainUse', False) else 0)
        S1(block.get('HeroTitle', ""))
        S1(block.get('ImagePath', ""))
        S1(block.get('CharacterInfo', ""))
        U("<i", block.get('RecommendPosition', 0))
        block_data.append(block.get('bAttackDistanceType', 0))
        U("<i", block.get('SightR', 0))
        U("<i", block.get('BaseHP', 0))
        U("<i", block.get('BaseHPAdd', 0))
        U("<i", block.get('HPAddLvlup', 0))
        U("<i", block.get('BaseATT', 0))
        U("<i", block.get('BaseINT', 0))
        U("<i", block.get('BaseDEF', 0))
        U("<i", block.get('BaseRES', 0))
        U("<i", block.get('BaseSpeed', 0))
        U("<i", block.get('AtkSpdAddLvlup', 0))
        U("<i", block.get('BaseAtkSpd', 0))
        U("<i", block.get('CritRate', 0))
        U("<i", block.get('CritEft', 0))
        U("<i", block.get('HpGrowth', 0))
        U("<i", block.get('AtkGrowth', 0))
        U("<i", block.get('SpellGrowth', 0))
        U("<i", block.get('DefGrowth', 0))
        U("<i", block.get('ResistGrowth', 0))
        U("<i", block.get('PassiveID1', 0))
        U("<i", block.get('PassiveID2', 0))
        U("<i", block.get('BuffID1', 0))
        U("<i", block.get('BuffID2', 0))
        U("<i", block.get('BuffID3', 0))
        for skill in block.get('SkillInfo', [{}] * 5):
            U("<i", skill.get("SkillID", 0))
            U("<i", skill.get("PassiveSkillID", 0))
            U("<H", skill.get("UnlockStar", 0))
            U("<I", skill.get("SkillBeanID", 0))
        U("<i", block.get('InitialStar', 0))
        block_data.append(block.get('bType', 0))
        block_data.append(block.get('bExpandType', 0))
        U("<H", block.get('PVPNeedLevel', 0))
        U("<i", block.get('PVPNeedQuality', 0))
        U("<i", block.get('PVPNeedSubQuality', 0))
        U("<i", block.get('PVPNeedStar', 0))
        U("<i", block.get('Viability', 0))
        U("<i", block.get('PhyDamage', 0))
        U("<i", block.get('SpellDamage', 0))
        U("<i", block.get('StartedDifficulty', 0))
        block_data.append(block.get('bJob', 0))
        block_data.append(block.get('bSecondJob', 0))
        job_feature = block.get('JobFeature', [0] * 2)
        job_feature += [0] * (2 - len(job_feature))
        for val in job_feature:
            U("<i", val)
        block_data.append(block.get('bDamageType', 0))
        block_data.append(block.get('bAttackType', 0))
        S1(block.get('HeroDesc', ""))
        S1(block.get('NewbieHeroDesc', ""))
        block_data.append(1 if block.get('bIOSHide', False) else 0)
        U("<I", block.get('ShowSortId', 0))
        S1(block.get('AI_Entry', ""))
        S1(block.get('AI_Simple', ""))
        S1(block.get('AI_Normal', ""))
        S1(block.get('AI_Hard', ""))
        S1(block.get('AI_WarmSimple', ""))
        S1(block.get('AI_Warm', ""))
        S1(block.get('AI_WarmFiveCamp', ""))
        S1(block.get('WakeDesc', ""))
        U("<I", block.get('WakeTalentID', 0))
        U("<I", block.get('WakeSkinID', 0))
        S1(block.get('AttackRangeDesc', ""))
        U("<I", block.get('EnergyType', 0))
        U("<i", block.get('Energy', 0))
        U("<i", block.get('EnergyGrowth', 0))
        U("<i", block.get('EnergyRec', 0))
        U("<i", block.get('EnergyRecGrowth', 0))
        U("<I", block.get('EnergyType2', 0))
        U("<i", block.get('Energy2', 0))
        U("<i", block.get('EnergyGrowth2', 0))
        U("<i", block.get('EnergyRec2', 0))
        U("<i", block.get('EnergyRecGrowth2', 0))
        S1(block.get('HeroTips', ""))
        S1(block.get('HeroSound', ""))
        U("<I", block.get('SymbolRcmdID', 0))
        S1(block.get('Born_Age', ""))
        S1(block.get('Revive_Age', ""))
        U("<I", block.get('DeadControl', 0))
        block_data.append(block.get('bTag', 0))
        block_data.append(block.get('bHeroCamp', 0))
        block_data.append(1 if block.get('bIsDCHero', False) else 0)
        block_data.append(1 if block.get('bIsHeroStoryLink', False) else 0)
        U("<i", block.get('BuffMarkSlotNum', 0))
        U("<i", block.get('BuffMarkOverlapRule', 0))
        S1(block.get('HeroWarmTips', ""))
        S1(block.get('HeroTrainDrawPicName', ""))
        U("<i", block.get('RecentAdapter', 0))
        U("<Q", block.get('AdapterBeginTime', 0))
        U("<Q", block.get('AdapterEndTime', 0))
        S1(block.get('AdapterURL', ""))
        S1(block.get('HeroStoryURL', ""))
        U("<I", block.get('MainLane', 0))
        U("<I", block.get('ViceLane', 0))
        not_recommended = block.get('NotRecommendedLane', [0] * 4)
        not_recommended += [0] * (4 - len(not_recommended))
        for val in not_recommended:
            U("<I", val)
        S1(block.get('HeroReportDrawPicName', ""))
        U("<i", block.get('HeroDrawPicNameUpdated', 0))
        hero_battle_skill = block.get('HeroBattleSkill', [0] * 10)
        hero_battle_skill += [0] * (10 - len(hero_battle_skill))
        for val in hero_battle_skill:
            U("<I", val)
        U("<I", block.get('DefaultSelSkill', 0))
        U("<I", block.get('SkillLevelUpGuide', 0))
        U("<I", block.get('NormalGoldNeedScore', 0))
        U("<I", block.get('NormalSilverNeedScore', 0))
        U("<I", block.get('MasterGoldNeedScore', 0))
        U("<I", block.get('MasterSilverNeedScore', 0))
        U("<I", block.get('RankStarGoldNeedScore', 0))
        U("<I", block.get('RankStarSilverNeedScore', 0))
        U("<I", block.get('RankDiamondGoldNeedScore', 0))
        U("<I", block.get('RankDiamondSilverNeedScore', 0))
        U("<I", block.get('RankPlatinumGoldNeedScore', 0))
        U("<I", block.get('RankPlatinumSilverNeedScore', 0))
        U("<I", block.get('RankBronzeGoldNeedScore', 0))
        U("<I", block.get('RankBronzeSilverNeedScore', 0))
        U("<I", block.get('MinimalScore', 0))
        U("<I", block.get('GoldGuarantee', 0))
        U("<I", block.get('AILane', 0))
        U("<I", block.get('NormalHeroID', 0))
        S1(block.get('HeroFightDesc', ""))
        second_skill_info = block.get('SecondSkillInfo', [0] * 4)
        second_skill_info += [0] * (4 - len(second_skill_info))
        for val in second_skill_info:
            U("<i", val)
        S1(block.get('HeroStrategy', ""))
        S1(block.get('HeroAdjustContent', ""))
        block_data.append(1 if block.get('bIsInTestingHero', False) else 0)
        S1(block.get('HeroCounterTips', ""))
        for mvp in block.get('HighlightMvpInfo', [{}] * 8):
            U("<I", mvp.get("MvpStdScore", 0))
            U("<I", mvp.get("MvpMinScore", 0))
        S1(block.get('ReturnExtarJson', ""))


        Blen = len(block_data)
        final_block = struct.pack("<I", Blen) + block_data
        binary_data.extend(final_block)
        Bflast = Blen
 

    Blast = Bflast + 4
    binary_data[8:12] = struct.pack("<I", Blast)
    md5_hash = hashlib.md5(binary_data[140:]).hexdigest().encode('utf-8')
    binary_data[96:96 + len(md5_hash)] = md5_hash
    binary_data[140 - 12:140] = b'\x00\x00\x00\x00\x8c\x00\x00\x00\x00\x00\x00\x00'

    with open(binary_file, "wb") as bf:
        bf.write(binary_data)

def pack_string(value):
    encoded = value.encode('utf-8') + b'\x00'
    length = len(encoded)
    return struct.pack("<I", length) + encoded

def vinh(directory,mode):
    if mode == "1":
        with open(os.path.join(directory, "hero.bytes"), "rb") as f:
            json_data = B2Js(f.read())
        with open(os.path.join(directory, "hero.json"), "w", encoding="utf-8") as json_file:
            json_file.write(json_data)
        print("output: hero.json")

    elif mode == "2":
        json_file_path = os.path.join(directory, "hero.json")
        with open(json_file_path, "r", encoding="utf-8") as json_file:
            json_data = json_file.read()
        JstoB(json_data, os.path.join(directory, "hero.bytes"))
        print("output: hero.bytes")


