import struct
import json
import os

def B2Js(blocks_data):
    offset = 140
    blocks = []
    def S():
        nonlocal offset
        value = struct.unpack_from("<I", blocks_data, offset)[0]
        offset += 4
        return value

    def B1():
        nonlocal offset
        value = struct.unpack_from("<B", blocks_data, offset)[0]
        return value

    def Str():
        nonlocal offset
        length = struct.unpack_from("<I", blocks_data, offset)[0]
        offset += 4
        value = blocks_data[offset : offset + length].decode("utf-8").strip("\x00")
        offset += length
        return value

    while offset < len(blocks_data):
        block = {}
        blockinfo = S()
        block['ID'] = S()
        block['HeroID'] = S()
        block['HeroName'] = Str()
        block['SkinID'] = S()
        block['SkinName'] = Str()
        block['SkinPicID'] = Str()
        block['BaseCfgID'] = S()
        block['CombatAbility'] = S()
        block['None'] = any(blocks_data[offset:offset + 105]) != 0
        offset += 105
        block['GetGoldGain'] = S()
        block['GetGoldUpperLimitGain'] = S()
        block['PresentHeadImg'] = S()
        block['HeroSkinShareUrl'] = Str()
        block['SettleShareUrl'] = Str()
        block['WinRateShareUrl'] = Str()
        block['SkinShowUrl'] = Str()
        blockFeature = S()
        block['SkinFeature'] = []
        for i in range(1, 11):
            icon = Str()
            name = Str()
            if icon or name:
                block['SkinFeature'].append({"Icon": icon, "Name": name})

        block['SkinBgAndTable'] = Str()
        block['VideoWeb'] = Str()
        block['VideoCover'] = Str()
        block['LoadingProjectBox'] = Str()
        block['CoinMultiple'] = S()
        block['CoinMultipleLimit'] = S()
        block['HeroSelectBuySkinBgColor'] = Str()
        block['HeroLabel'] = Str()
        block['HeroLabelColor'] = Str()
        block['HeroLabelDesc'] = Str()
        flags = struct.unpack_from("<5B", blocks_data, offset)
        offset += 5
        block['bHideUI'] = flags[0] == 1
        block['bDisableRot'] = flags[1] == 1
        block['bDisableBloom'] = flags[2] == 1
        block['bDisableDirLight'] = flags[3] == 1
        block['bScaleCamera'] = int(flags[4])

        block['IsRecommendAIUsed'] = S()
        block['bEnableComponentLight'] = B1() == 1
        offset += 1
        block['iPresentSkinMotion'] = S()
        block['bIsDLC'] = B1()
        offset += 1
        block['bIsInAB'] = B1() == 1
        offset += 1
        block['DLCWeight'] = S()
        block['Rarity'] = S()
        block['Level'] = S()
        block['Series'] = S()
        block['SkinPicCDNPath'] = Str()
        block['SkinHeadCDNPath'] = Str()
        block['TalePageCDNPath'] = Str()
        block['SkinDynamicPath'] = B1()
        offset += 1
        block['bIsHeroSkinShareTextOnRight'] = B1() == 1
        offset += 1
        block['HeroVoiceActor'] = Str()
        block['bUseDefaultBackground'] = B1() == 1
        offset += 1
        block['iSkinThemeID'] = S()
        block['SkinThemeName'] = Str()
        block['HomePageSkinBgAndTable'] = Str()
        block['ImprintAge'] = Str()
        block['ReturnExtarJson'] = Str()
        blocks.append(block)

    return json.dumps(blocks, indent=4)

import hashlib


def JstoB(json_data, binary_file):
    blocks = json.loads(json_data)
    binary_data = bytearray()
    header = bytearray()
    header.extend(b'MSES\x07\x00\x00\x00')
    Blast = 0
    total_blocks = len(blocks)
    header.extend(struct.pack("<I", Blast))
    header.extend(struct.pack("<I", total_blocks))
    header.extend(b'\x61' * 32)
    header.extend(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00UTF-8\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    header.extend(b'\x00' * (140 - len(header)))
    binary_data.extend(header)

    def U(fmt, value):
        nonlocal block_data
        block_data.extend(struct.pack(fmt, value))
    
    def S1(value):
        nonlocal block_data
        block_data.extend(pack_string(value))

    for block in blocks:
        block_data = bytearray()

        U("<I", block.get('ID', 0))
        U("<I", block.get('HeroID', 0))
        S1(block.get('HeroName', ""))
        U("<I", block.get('SkinID', 0))
        S1(block.get('SkinName', ""))
        S1(block.get('SkinPicID', ""))
        U("<I", block.get('BaseCfgID', 0))
        U("<I", block.get('CombatAbility', 0))

        has_data = b'\x01' if block.get('None', False) else b'\x00'
        
        if has_data == b'\x01':
            block_data.extend(b'\x01\x00\x00\x0A\x00\x00\x00\x00' + b'\x00' * 97)
        else:
            block_data.extend(b'\x00' * 105)

        U("<I", block.get('GetGoldGain', 0))
        U("<I", block.get('GetGoldUpperLimitGain', 0))
        U("<I", block.get('PresentHeadImg', 0))
        S1(block.get('HeroSkinShareUrl', ""))
        S1(block.get('SettleShareUrl', ""))
        S1(block.get('WinRateShareUrl', ""))
        S1(block.get('SkinShowUrl', ""))
        features = block.get("SkinFeature", [])
        U("<I", len(features))
        for i in range(10):
            if i < len(features):
                S1(features[i].get("Icon", ""))
                S1(features[i].get("Name", ""))
            else:
                S1("")
                S1("")
        S1(block.get('SkinBgAndTable', ""))
        S1(block.get('VideoWeb', ""))
        S1(block.get('VideoCover', ""))
        S1(block.get('LoadingProjectBox', ""))
        U("<I", block.get('CoinMultiple', 0))
        U("<I", block.get('CoinMultipleLimit', 0))
        S1(block.get('HeroSelectBuySkinBgColor', ""))
        S1(block.get('HeroLabel', ""))
        S1(block.get('HeroLabelColor', ""))
        S1(block.get('HeroLabelDesc', ""))
        flags = [
            1 if block.get('bHideUI', False) else 0,
            1 if block.get('bDisableRot', False) else 0,
            1 if block.get('bDisableBloom', False) else 0,
            1 if block.get('bDisableDirLight', False) else 0,
        ]
        block_data.extend(struct.pack("<4B", *flags))
        bScaleCamera = block.get('bScaleCamera', 0)
        block_data.append(bScaleCamera)

        U("<I", block.get('IsRecommendAIUsed', 0))
        block_data.append(1 if block.get('bEnableComponentLight', False) else 0)
        U("<I", block.get('iPresentSkinMotion', 0))
        block_data.append(block.get('bIsDLC', 0))
        block_data.append(1 if block.get('bIsInAB', False) else 0)
        U("<I", block.get('DLCWeight', 0))
        U("<I", block.get('Rarity', 0))
        U("<I", block.get('Level', 0))
        U("<I", block.get('Series', 0))
        S1(block.get('SkinPicCDNPath', ""))
        S1(block.get('SkinHeadCDNPath', ""))
        S1(block.get('TalePageCDNPath', ""))
        block_data.append(block.get('SkinDynamicPath', 0))
        block_data.append(1 if block.get('bIsHeroSkinShareTextOnRight', False) else 0)
        S1(block.get('HeroVoiceActor', ""))
        block_data.append(1 if block.get('bUseDefaultBackground', False) else 0)
        U("<I", block.get('iSkinThemeID', 0))
        S1(block.get('SkinThemeName', ""))
        S1(block.get('HomePageSkinBgAndTable', ""))
        S1(block.get('ImprintAge', ""))
        S1(block.get('ReturnExtarJson', ""))

        Blen = len(block_data)
        final_block = struct.pack("<I", Blen) + block_data
        binary_data.extend(final_block)
        Bflast = Blen
 

    Blast = Bflast + 4
    binary_data[8:12] = struct.pack("<I", Blast)
    md5_hash = hashlib.md5(binary_data[140:]).hexdigest().encode('utf-8')
    binary_data[96:96 + len(md5_hash)] = md5_hash
    binary_data[140 - 12:140] = b'\x00\x00\x00\x00\x8c\x00\x00\x00\x00\x00\x00\x00'

    with open(binary_file, "wb") as bf:
        bf.write(binary_data)


def pack_string(value):
    encoded = value.encode('utf-8') + b'\x00'
    length = len(encoded)
    return struct.pack("<I", length) + encoded


def vinh(directory,mode):
    if mode == "1":
        with open(os.path.join(directory, "heroSkin.bytes"), "rb") as f:
            json_data = B2Js(f.read())
        with open(os.path.join(directory, "heroSkin.json"), "w", encoding="utf-8") as json_file:
            json_file.write(json_data)
        print("output: heroSkin.json")

    elif mode == "2":
        json_file_path = os.path.join(directory, "heroSkin.json")
        with open(json_file_path, "r", encoding="utf-8") as json_file:
            json_data = json_file.read()
        JstoB(json_data, os.path.join(directory, "heroSkin.bytes"))
        print("output: heroSkin.bytes")


