import struct
import json
import os


def B2Js(blocks_data):
    offset = 140
    blocks = []
    def rv(fmt, size):
        nonlocal offset
        value = struct.unpack_from(fmt, blocks_data, offset)[0]
        offset += size
        return value
    def rvb():
        return rv("<B", 1) == 1
    def S(): return rv("<I", 4)
    def S2(): return rv("<H", 2)
    def S8(): return rv("<Q", 8)
    def I(): return rv("<i", 4)
    def I2(): return rv("<h", 2)
    def I8(): return rv("<q", 8)
    def B1(): return rv("<B", 1)
    def B2(): return rvb()
    
    def Str():
        nonlocal offset
        length = S()
        raw_bytes = blocks_data[offset:offset + length]
        offset += length
        return raw_bytes.decode("utf-8", errors="replace").strip("\x00")



    while offset < len(blocks_data):
        block = {}
        try:
            blockinfo = S()
            block['CfgID'] = I()
            block['SkillName'] = Str()
            block['bMapSkillCfgUseRuleID'] = B1()
            block['SkillDesc'] = Str()
            block['SkillDescBrief'] = Str()
            block['LobbySkillDesc'] = Str()
            
            block['SkillDesParam'] = []
            for _ in range(8):
                value = Str()
                block['SkillDesParam'].append(value)
            block['bSkillType'] = B1()
            block['bWheelType'] = B1()
            
            block['SubSkillGroup'] = []
            for _ in range(3):
                value = I()
                block['SubSkillGroup'].append(value)
            block['SkillValueDesc'] = Str()
            block['SkillUpTip'] = Str()
            block['IconPath'] = Str()
            block['bSelectEffectPrefab'] = B1()
            block['GuidePrefab'] = Str()
            block['EffectPrefab'] = Str()
            block['FixedPrefab'] = Str()
            block['EffectSelectTargetPrefab'] = Str()
            block['GuidePrefabSpecial'] = Str()
            block['EffectPrefabSpecial'] = Str()
            block['FixedPrefabSpecial'] = Str()
            block['EffectSelectTargetPrefabSpecial'] = Str()
            block['MapIndicatorNormalPrefab'] = Str()
            block['MapIndicatorRedPrefab'] = Str()
            block['SmallMapIndicatorHeight'] = I()
            block['BigMapIndicatorHeight'] = I()
            block['CoolDown'] = I()
            block['bCDindependent'] = B1()
            block['bIsIngoreCDReduce'] = B2()
            block['bImmediateUse'] = B1()
            block['bImmediateUseNoAutoCD'] = B1()
            block['bIsInterruptImmediateUseSkill'] = B2()
            block['bBIngnoreDisable'] = B1()
            block['Prefab'] = Str()
            block['SkillUseCancelCombineID'] = S()
            block['SelfSkillCombine'] = I()
            block['TargetSkillCombine'] = I()
            block['RangeAppointType'] = S()
            block['bIndicatorType'] = B1()
            block['RangeRadius'] = I()
            block['TgtIncludeSelf'] = S()
            block['TgtIncludeEnemy'] = S()
            block['BaseDamage'] = I()
            block['FixedDistance'] = I()
            block['GuideDistance'] = I()
            block['MaxAttackDistance'] = I()
            block['GreaterAttackDistance'] = I()
            block['MaxSearchDistance'] = I()
            block['MaxSearchDistanceGrowthValue'] = I()
            block['MaxChaseDistance'] = I()
            block['AddSearchDistance'] = I()
            block['IsBullet'] = S()
            block['BulletID'] = I()
            block['SkillUseRule'] = S()
            block['SkillTargetRule'] = S()
            block['SkillTargetFilter'] = S()
            block['SkillCombatType'] = I()
            block['bIsCheckAntiCheat'] = B1()
            
            block['SkillEffectType'] = []
            for _ in range(3):
                value = S()
                block['SkillEffectType'].append(value)
            block['bAutoEnergyCost'] = B1()
            block['EnergyCostType'] = S()
            block['EnergyCostCalcType'] = I()
            block['EnergyCost'] = I()
            block['EnergyCostGrowth'] = I()
            block['CoolDownGrowth'] = I()
            block['bIsStunSkill'] = B1()
            block['bNoInfluenceAnim'] = B1()
            block['bNoInfluenceCd'] = B1()
            block['bAgeImmeExcute'] = B1()
            SkillPropertyCnt = B1()
            
            
            block['SkillDescription'] = []
            for _ in range(SkillPropertyCnt):
                skill = {
                    "SkillDescType": Str(),
                    "SkillDescBaseValue": Str(),
                    "SkillDescGrowth": Str(),
                    "SkillDescValueType": S(),
                }
                block['SkillDescription'].append(skill)
                
                
            block['bSkillNonExposing'] = B1()
            block['bSkillIndicatorFocusOnCallMonster'] = B1()
            block['bNewCfgIndicatorResType'] = B1()
            block['NewCfgIndicatorSize'] = I()
            block['bNewCfgIndicatorObjType'] = B1()
            block['SkillHurtNum'] = Str()
            block['AllTeamShareSkillCDGroupID'] = S()
            block['SkillBeanID'] = S()
            block['ChargeSkillEffectID'] = S()
            block['EndChargeSkillEffectID'] = S()
            block['bChargeSkillType'] = B1()
            block['ChargeTimeUpperLimit'] = S()
            block['ChargeTimeValid'] = S()
            block['SkillDirRange'] = S()
            block['CancleChargingCDRatio'] = S()
            block['bCancelChargingForceUse'] = B1()
            block['bSkillDirControlMove'] = B1()
            block['bSendSkillIndicatorPos'] = B1()
            block['bConsumeBean'] = B1()
            block['bCameraMoveWithIndicator'] = B1()
            block['CameraIndicatorThreshold'] = I()
            block['CameraIndicatorStayTime'] = I()
            block['bCameraMoveWithJoystick'] = B2()
            block['bIsStrengthenSkill'] = B2()
            block['bCheckBlock'] = B2()
            block['bDontTriggerEvent'] = B2()
            block['SkillPicCDNPath'] = Str()
            block['bSelectTargetDontShowRedLine'] = B1()
            block['MapIndicatorHitPrefab'] = Str()
            block['BulletWight'] = I()
            block['IsCoreSkill'] = S()
            block['CoreSkillTip'] = Str()
            block['ShowMapIndicatorHitPrefabDelay'] = I()
            block['PreCfgID'] = I()
            
            



            
            blocks.append(block)
        except ValueError as e:
            print(f"Error reading block at offset {offset}: {e}")
            break

    return json.dumps(blocks, ensure_ascii=False, indent=4)

    



import hashlib


def JstoB(json_data, binary_file):
    blocks = json.loads(json_data)
    binary_data = bytearray()
    header = bytearray()
    header.extend(b'MSES\x07\x00\x00\x00')
    Blast = 0
    total_blocks = len(blocks)
    header.extend(struct.pack("<I", Blast))
    header.extend(struct.pack("<I", total_blocks))
    header.extend(b'\x61' * 32)
    header.extend(b'\x00' * 16 + b'UTF-8' + b'\x00' * 23)
    header.extend(b'\x00' * (140 - len(header)))
    binary_data.extend(header)

    def U(fmt, value):
        nonlocal block_data
        block_data.extend(struct.pack(fmt, value))
    def S1(value):
        nonlocal block_data
        block_data.extend(pack_string(value))
    for block in blocks:
        block_data = bytearray()
                
        U("<i", block.get('CfgID', 0))
        S1(block.get('SkillName', ""))
        block_data.append(block.get('bMapSkillCfgUseRuleID', 0))
        S1(block.get('SkillDesc', ""))
        S1(block.get('SkillDescBrief', ""))
        S1(block.get('LobbySkillDesc', ""))
        for param in block['SkillDesParam']:
            S1(param)
        
        
        block_data.append(block.get('bSkillType', 0))
        block_data.append(block.get('bWheelType', 0))
        for Skill in block['SubSkillGroup']:
            U("<i", Skill)
        
        S1(block.get('SkillValueDesc', ""))
        S1(block.get('SkillUpTip', ""))
        S1(block.get('IconPath', ""))
        block_data.append(block.get('bSelectEffectPrefab', 0))
        S1(block.get('GuidePrefab', ""))
        S1(block.get('EffectPrefab', ""))
        S1(block.get('FixedPrefab', ""))
        S1(block.get('EffectSelectTargetPrefab', ""))
        S1(block.get('GuidePrefabSpecial', ""))
        S1(block.get('EffectPrefabSpecial', ""))
        S1(block.get('FixedPrefabSpecial', ""))
        S1(block.get('EffectSelectTargetPrefabSpecial', ""))
        S1(block.get('MapIndicatorNormalPrefab', ""))
        S1(block.get('MapIndicatorRedPrefab', ""))
        U("<i", block.get('SmallMapIndicatorHeight', 0))
        U("<i", block.get('BigMapIndicatorHeight', 0))
        U("<i", block.get('CoolDown', 0))
        block_data.append(block.get('bCDindependent', 0))
        block_data.append(1 if block.get('bIsIngoreCDReduce', False) else 0)
        block_data.append(block.get('bImmediateUse', 0))
        block_data.append(block.get('bImmediateUseNoAutoCD', 0))
        block_data.append(1 if block.get('bIsInterruptImmediateUseSkill', False) else 0)
        block_data.append(block.get('bBIngnoreDisable', 0))
        S1(block.get('Prefab', ""))
        U("<I", block.get('SkillUseCancelCombineID', 0))
        U("<i", block.get('SelfSkillCombine', 0))
        U("<i", block.get('TargetSkillCombine', 0))
        U("<I", block.get('RangeAppointType', 0))
        block_data.append(block.get('bIndicatorType', 0))
        U("<i", block.get('RangeRadius', 0))
        U("<I", block.get('TgtIncludeSelf', 0))
        U("<I", block.get('TgtIncludeEnemy', 0))
        U("<i", block.get('BaseDamage', 0))
        U("<i", block.get('FixedDistance', 0))
        U("<i", block.get('GuideDistance', 0))
        U("<i", block.get('MaxAttackDistance', 0))
        U("<i", block.get('GreaterAttackDistance', 0))
        U("<i", block.get('MaxSearchDistance', 0))
        U("<i", block.get('MaxSearchDistanceGrowthValue', 0))
        U("<i", block.get('MaxChaseDistance', 0))
        U("<i", block.get('AddSearchDistance', 0))
        U("<I", block.get('IsBullet', 0))
        U("<i", block.get('BulletID', 0))
        U("<I", block.get('SkillUseRule', 0))
        U("<I", block.get('SkillTargetRule', 0))
        U("<I", block.get('SkillTargetFilter', 0))
        U("<i", block.get('SkillCombatType', 0))
        block_data.append(block.get('bIsCheckAntiCheat', 0))
        
        for Skill in block['SkillEffectType']:
            U("<I", Skill)
        
        block_data.append(block.get('bAutoEnergyCost', 0))
        U("<I", block.get('EnergyCostType', 0))
        U("<i", block.get('EnergyCostCalcType', 0))
        U("<i", block.get('EnergyCost', 0))
        U("<i", block.get('EnergyCostGrowth', 0))
        U("<i", block.get('CoolDownGrowth', 0))
        block_data.append(block.get('bIsStunSkill', 0))
        block_data.append(block.get('bNoInfluenceAnim', 0))
        block_data.append(block.get('bNoInfluenceCd', 0))
        block_data.append(block.get('bAgeImmeExcute', 0))
        
        SkillPropertyCnt = len(block.get('SkillDescription', []))
        block_data.append(SkillPropertyCnt)
        for effect in block['SkillDescription']:
            S1(effect["SkillDescType"])
            S1(effect["SkillDescBaseValue"])
            S1(effect["SkillDescGrowth"])
            U("<I", effect["SkillDescValueType"])
        
        
        
        block_data.append(block.get('bSkillNonExposing', 0))
        block_data.append(block.get('bSkillIndicatorFocusOnCallMonster', 0))
        block_data.append(block.get('bNewCfgIndicatorResType', 0))
        U("<i", block.get('NewCfgIndicatorSize', 0))
        block_data.append(block.get('bNewCfgIndicatorObjType', 0))
        S1(block.get('SkillHurtNum', ""))
        U("<I", block.get('AllTeamShareSkillCDGroupID', 0))
        U("<I", block.get('SkillBeanID', 0))
        U("<I", block.get('ChargeSkillEffectID', 0))
        U("<I", block.get('EndChargeSkillEffectID', 0))
        block_data.append(block.get('bChargeSkillType', 0))
        U("<I", block.get('ChargeTimeUpperLimit', 0))
        U("<I", block.get('ChargeTimeValid', 0))
        U("<I", block.get('SkillDirRange', 0))
        U("<I", block.get('CancleChargingCDRatio', 0))
        block_data.append(block.get('bCancelChargingForceUse', 0))
        block_data.append(block.get('bSkillDirControlMove', 0))
        block_data.append(block.get('bSendSkillIndicatorPos', 0))
        block_data.append(block.get('bConsumeBean', 0))
        block_data.append(block.get('bCameraMoveWithIndicator', 0))
        U("<i", block.get('CameraIndicatorThreshold', 0))
        U("<i", block.get('CameraIndicatorStayTime', 0))
        block_data.append(1 if block.get('bCameraMoveWithJoystick', False) else 0)
        block_data.append(1 if block.get('bIsStrengthenSkill', False) else 0)
        block_data.append(1 if block.get('bCheckBlock', False) else 0)
        block_data.append(1 if block.get('bDontTriggerEvent', False) else 0)
        S1(block.get('SkillPicCDNPath', ""))
        block_data.append(block.get('bSelectTargetDontShowRedLine', 0))
        S1(block.get('MapIndicatorHitPrefab', ""))
        U("<i", block.get('BulletWight', 0))
        U("<I", block.get('IsCoreSkill', 0))
        S1(block.get('CoreSkillTip', ""))
        U("<i", block.get('ShowMapIndicatorHitPrefabDelay', 0))
        U("<i", block.get('PreCfgID', 0))






        Blen = len(block_data)
        final_block = struct.pack("<I", Blen) + block_data
        binary_data.extend(final_block)
        Bflast = Blen
 

    Blast = Bflast + 4
    binary_data[8:12] = struct.pack("<I", Blast)
    md5_hash = hashlib.md5(binary_data[140:]).hexdigest().encode('utf-8')
    binary_data[96:96 + len(md5_hash)] = md5_hash
    binary_data[140 - 12:140] = b'\x00\x00\x00\x00\x8c\x00\x00\x00\x00\x00\x00\x00'

    with open(binary_file, "wb") as bf:
        bf.write(binary_data)


def pack_string(value):
    encoded = value.encode('utf-8') + b'\x00'
    length = len(encoded)
    return struct.pack("<I", length) + encoded




def vinh(directory,mode):
    if mode == "1":
        with open(os.path.join(directory, "skill.bytes"), "rb") as f:
            json_data = B2Js(f.read())
        with open(os.path.join(directory, "skill.json"), "w", encoding="utf-8") as json_file:
            json_file.write(json_data)
        print("output: skill.json")

    elif mode == "2":
        json_file_path = os.path.join(directory, "skill.json")
        with open(json_file_path, "r", encoding="utf-8") as json_file:
            json_data = json_file.read()
        JstoB(json_data, os.path.join(directory, "skill.bytes"))
        print("output: skill.bytes")


