import struct
import json
import os

def B2Js(blocks_data):
    offset = 140
    blocks = []
    def rv(fmt, size):
        nonlocal offset
        value = struct.unpack_from(fmt, blocks_data, offset)[0]
        offset += size
        return value
    def rvb():
        return rv("<B", 1) == 1
    def S(): return rv("<I", 4)
    def S2(): return rv("<H", 2)
    def S8(): return rv("<Q", 8)
    def I(): return rv("<i", 4)
    def I2(): return rv("<h", 2)
    def I8(): return rv("<q", 8)
    def B1(): return rv("<B", 1)
    def B2(): return rvb()
    
    def Str():
        nonlocal offset
        length = S()
        raw_bytes = blocks_data[offset:offset + length]
        offset += length
        return raw_bytes.decode("utf-8", errors="replace").strip("\x00")

    while offset < len(blocks_data):
        block = {}
        try:
            blockinfo = S()
            block['ID'] = I()
            block['MapID'] = I()
            block['ActorType'] = I()
            block['ActorSubType'] = I()
            block['ActorCfgID'] = I()
            block['HeroSkinID'] = I()
            block['OperateType'] = I()
            block['SkinID'] = I()



            
            blocks.append(block)
        except ValueError as e:
            print(f"Error reading block at offset {offset}: {e}")
            break

    return json.dumps(blocks, ensure_ascii=False, indent=4)

    



import hashlib


def JstoB(json_data, binary_file):
    blocks = json.loads(json_data)
    binary_data = bytearray()
    header = bytearray()
    header.extend(b'MSES\x07\x00\x00\x00')
    Blast = 0
    total_blocks = len(blocks)
    header.extend(struct.pack("<I", Blast))
    header.extend(struct.pack("<I", total_blocks))
    header.extend(b'\x61' * 32)
    header.extend(b'\x00' * 16 + b'UTF-8' + b'\x00' * 23)
    header.extend(b'\x00' * (140 - len(header)))
    binary_data.extend(header)

    def U(fmt, value):
        nonlocal block_data
        block_data.extend(struct.pack(fmt, value))
    def S1(value):
        nonlocal block_data
        block_data.extend(pack_string(value))
    for block in blocks:
        block_data = bytearray()
        
        
        U("<i", block.get('ID', 0))
        U("<i", block.get('MapID', 0))
        U("<i", block.get('ActorType', 0))
        U("<i", block.get('ActorSubType', 0))
        U("<i", block.get('ActorCfgID', 0))
        U("<i", block.get('HeroSkinID', 0))
        U("<i", block.get('OperateType', 0))
        U("<i", block.get('SkinID', 0))




        Blen = len(block_data)
        final_block = struct.pack("<I", Blen) + block_data
        binary_data.extend(final_block)
        Bflast = Blen
 

    Blast = Bflast + 4
    binary_data[8:12] = struct.pack("<I", Blast)
    md5_hash = hashlib.md5(binary_data[140:]).hexdigest().encode('utf-8')
    binary_data[96:96 + len(md5_hash)] = md5_hash
    binary_data[140 - 12:140] = b'\x00\x00\x00\x00\x8c\x00\x00\x00\x00\x00\x00\x00'

    with open(binary_file, "wb") as bf:
        bf.write(binary_data)


def pack_string(value):
    encoded = value.encode('utf-8') + b'\x00'
    length = len(encoded)
    return struct.pack("<I", length) + encoded




def vinh(directory,mode):
    if mode == "1":
        with open(os.path.join(directory, "organskin.bytes"), "rb") as f:
            json_data = B2Js(f.read())
        with open(os.path.join(directory, "organskin.json"), "w", encoding="utf-8") as json_file:
            json_file.write(json_data)
        print("output: organskin.json")

    elif mode == "2":
        json_file_path = os.path.join(directory, "organskin.json")
        with open(json_file_path, "r", encoding="utf-8") as json_file:
            json_data = json_file.read()
        JstoB(json_data, os.path.join(directory, "organskin.bytes"))
        print("output: organskin.bytes")


